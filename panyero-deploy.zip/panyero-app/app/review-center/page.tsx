"use client"

import { useState, useEffect } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Book, CheckCircle, Clock, ArrowRight, GraduationCap, Search, Brain, BookOpen, BarChart, Headphones } from 'lucide-react'
import { toast } from "sonner"
import { ResearchAudioPlayer } from "@/components/research-audio-player"

interface Course {
  id: number
  title: string
  progress: number
  duration: string
  description: string
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced'
  tags: string[]
}

interface Certification {
  id: number
  title: string
  expiryDate: string
  status: 'active' | 'expiring' | 'expired'
  requirements: string[]
}

interface StudyRecommendation {
  id: number
  title: string
  reason: string
  priority: 'High' | 'Medium' | 'Low'
}

export default function ReviewCenterPage() {
  const [activeCourses, setActiveCourses] = useState<Course[]>([])
  const [availableCourses, setAvailableCourses] = useState<Course[]>([])
  const [certifications, setCertifications] = useState<Certification[]>([])
  const [recommendations, setRecommendations] = useState<StudyRecommendation[]>([])
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    // In a real application, this would fetch from an API with AI-enriched data
    setActiveCourses([
      { 
        id: 1, 
        title: "Maritime Law", 
        progress: 75, 
        duration: "2h 30m",
        description: "Learn about international maritime laws and regulations",
        difficulty: "Intermediate",
        tags: ["Legal", "Regulations", "International"]
      },
      { 
        id: 2, 
        title: "Navigation Techniques", 
        progress: 50, 
        duration: "3h 45m",
        description: "Master modern navigation tools and techniques",
        difficulty: "Advanced",
        tags: ["Navigation", "Technical", "GPS"]
      },
      { 
        id: 3, 
        title: "Safety Procedures", 
        progress: 90, 
        duration: "1h 15m",
        description: "Essential safety protocols for maritime operations",
        difficulty: "Beginner",
        tags: ["Safety", "Emergency", "Protocols"]
      },
    ])

    setAvailableCourses([
      { 
        id: 4, 
        title: "Ship Maintenance", 
        progress: 0, 
        duration: "4h 00m",
        description: "Comprehensive guide to vessel maintenance",
        difficulty: "Advanced",
        tags: ["Maintenance", "Technical", "Engineering"]
      },
      { 
        id: 5, 
        title: "Environmental Regulations", 
        progress: 0, 
        duration: "2h 15m",
        description: "Learn about maritime environmental protection",
        difficulty: "Intermediate",
        tags: ["Environment", "Regulations", "Compliance"]
      },
    ])

    setCertifications([
      { 
        id: 1, 
        title: "Basic Safety Training", 
        expiryDate: "2025-12-31",
        status: 'active',
        requirements: [
          "Complete Safety Procedures course",
          "Pass practical assessment",
          "Complete first aid training"
        ]
      },
      { 
        id: 2, 
        title: "GMDSS Certification", 
        expiryDate: "2024-06-30",
        status: 'expiring',
        requirements: [
          "Complete Radio Communications course",
          "Pass GMDSS examination",
          "Complete practical radio operations"
        ]
      },
    ])

    setRecommendations([
      {
        id: 1,
        title: "Complete Navigation Techniques",
        reason: "Required for upcoming certification renewal",
        priority: "High"
      },
      {
        id: 2,
        title: "Start Environmental Regulations",
        reason: "New regulations coming into effect next quarter",
        priority: "Medium"
      }
    ])
  }, [])

  const handleContinueCourse = (courseId: number) => {
    toast.info(`Continuing course ${courseId}`)
  }

  const handleStartCourse = (courseId: number) => {
    const course = availableCourses.find(c => c.id === courseId)
    if (course) {
      setActiveCourses([...activeCourses, { ...course, progress: 0 }])
      setAvailableCourses(availableCourses.filter(c => c.id !== courseId))
      toast.success(`Started course: ${course.title}`)
    }
  }

  const handleViewCertification = (certId: number) => {
    toast.info(`Viewing certification ${certId}`)
  }

  const filteredActiveCourses = activeCourses.filter(course => 
    course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  const filteredAvailableCourses = availableCourses.filter(course =>
    course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    course.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <div className="flex flex-col space-y-4 md:flex-row md:justify-between md:items-center md:space-y-0">
          <h1 className="text-2xl font-bold">Review Center</h1>
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search courses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8"
            />
          </div>
        </div>

        <Tabs defaultValue="courses" className="space-y-4">
          <TabsList>
            <TabsTrigger value="courses" className="flex items-center">
              <BookOpen className="mr-2 h-4 w-4" />
              Courses
            </TabsTrigger>
            <TabsTrigger value="certifications" className="flex items-center">
              <GraduationCap className="mr-2 h-4 w-4" />
              Certifications
            </TabsTrigger>
            <TabsTrigger value="recommendations" className="flex items-center">
              <Brain className="mr-2 h-4 w-4" />
              AI Recommendations
            </TabsTrigger>
            <TabsTrigger value="research" className="flex items-center">
              <Headphones className="mr-2 h-4 w-4" />
              Research Audio
            </TabsTrigger>
          </TabsList>

          <TabsContent value="courses" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Book className="mr-2 h-5 w-5" />
                  Active Courses
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredActiveCourses.map(course => (
                    <div key={course.id} className="border-b pb-4 last:border-b-0 last:pb-0">
                      <div className="flex justify-between items-center mb-2">
                        <div>
                          <h3 className="font-medium">{course.title}</h3>
                          <p className="text-sm text-muted-foreground">{course.description}</p>
                          <div className="flex gap-2 mt-1">
                            {course.tags.map(tag => (
                              <span key={tag} className="text-xs bg-secondary text-secondary-foreground px-2 py-1 rounded-full">
                                {tag}
                              </span>
                            ))}
                          </div>
                        </div>
                        <span className="text-sm text-muted-foreground">{course.progress}%</span>
                      </div>
                      <Progress value={course.progress} className="mb-2" />
                      <div className="flex justify-between items-center text-sm text-muted-foreground">
                        <div className="flex items-center gap-4">
                          <span className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {course.duration}
                          </span>
                          <span className="flex items-center">
                            <BarChart className="w-4 h-4 mr-1" />
                            {course.difficulty}
                          </span>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-primary hover:text-primary" 
                          onClick={() => handleContinueCourse(course.id)}
                        >
                          Continue <ArrowRight className="w-4 h-4 ml-1" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Available Courses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredAvailableCourses.map(course => (
                    <div key={course.id} className="flex justify-between items-center">
                      <div>
                        <h3 className="font-medium">{course.title}</h3>
                        <p className="text-sm text-muted-foreground">{course.description}</p>
                        <div className="flex gap-2 mt-1">
                          <span className="text-xs text-muted-foreground">
                            <Clock className="w-3 h-3 inline mr-1" />
                            {course.duration}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            <BarChart className="w-3 h-3 inline mr-1" />
                            {course.difficulty}
                          </span>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => handleStartCourse(course.id)}>
                        Start Course
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="certifications">
            <Card>
              <CardHeader>
                <CardTitle>My Certifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {certifications.map(cert => (
                    <div key={cert.id} className="border-b last:border-b-0 pb-4 last:pb-0">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-start gap-2">
                          <GraduationCap className={`w-5 h-5 mt-1 ${
                            cert.status === 'active' ? 'text-green-500' :
                            cert.status === 'expiring' ? 'text-yellow-500' :
                            'text-red-500'
                          }`} />
                          <div>
                            <h3 className="font-medium">{cert.title}</h3>
                            <p className="text-sm text-muted-foreground">
                              Valid until {cert.expiryDate}
                            </p>
                            <div className="mt-2">
                              <p className="text-sm font-medium mb-1">Requirements:</p>
                              <ul className="list-disc list-inside text-sm text-muted-foreground">
                                {cert.requirements.map((req, index) => (
                                  <li key={index}>{req}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => handleViewCertification(cert.id)}>
                          View
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recommendations">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="mr-2 h-5 w-5" />
                  AI-Powered Learning Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recommendations.map(rec => (
                    <div key={rec.id} className="flex items-start gap-4 p-4 rounded-lg bg-secondary">
                      <div className="flex-1">
                        <h3 className="font-medium flex items-center gap-2">
                          {rec.title}
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            rec.priority === 'High' ? 'bg-red-100 text-red-800' :
                            rec.priority === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-green-100 text-green-800'
                          }`}>
                            {rec.priority} Priority
                          </span>
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">{rec.reason}</p>
                      </div>
                      <Button size="sm">
                        Take Action
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="research">
            <ResearchAudioPlayer />
          </TabsContent>
        </Tabs>
      </div>

      <BottomNav />
    </main>
  )
}

