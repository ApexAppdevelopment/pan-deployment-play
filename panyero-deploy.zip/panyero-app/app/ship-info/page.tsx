"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Anchor, Ship, Users, Calendar, FileText, Pencil, Save } from 'lucide-react'
import { toast } from "sonner"

interface ShipDetails {
  name: string
  type: string
  imo: string
  flag: string
  crew: number
  nextPort: string
  eta: string
}

interface Document {
  name: string
  expiry: string
}

export default function ShipInfoPage() {
  const [isEditing, setIsEditing] = useState(false)
  const [shipDetails, setShipDetails] = useState<ShipDetails>({
    name: "MV Pacific Voyager",
    type: "Container Ship",
    imo: "IMO 9876543",
    flag: "Panama",
    crew: 25,
    nextPort: "Singapore",
    eta: "2024-01-15",
  })

  const [documents, setDocuments] = useState<Document[]>([
    { name: "Ship Certificate", expiry: "2024-12-31" },
    { name: "Safety Management Certificate", expiry: "2024-06-30" },
    { name: "International Oil Pollution Prevention", expiry: "2024-09-15" },
  ])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setShipDetails(prev => ({ ...prev, [name]: value }))
  }

  const handleDocumentChange = (index: number, field: keyof Document, value: string) => {
    const newDocuments = [...documents]
    newDocuments[index][field] = value
    setDocuments(newDocuments)
  }

  const handleSave = () => {
    setIsEditing(false)
    toast.success("Ship information updated successfully")
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="space-y-6 p-4">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Ship Information</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsEditing(!isEditing)}
            aria-label={isEditing ? "Save changes" : "Edit information"}
          >
            {isEditing ? <Save className="h-5 w-5" /> : <Pencil className="h-5 w-5" />}
          </Button>
        </div>
        
        <div className="rounded-lg bg-white p-4 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <Ship className="h-8 w-8 text-blue-600" />
            <div>
              {isEditing ? (
                <Input
                  name="name"
                  value={shipDetails.name}
                  onChange={handleInputChange}
                  className="font-semibold text-lg"
                />
              ) : (
                <h2 className="font-semibold text-lg">{shipDetails.name}</h2>
              )}
              {isEditing ? (
                <Input
                  name="type"
                  value={shipDetails.type}
                  onChange={handleInputChange}
                  className="text-sm text-gray-600"
                />
              ) : (
                <p className="text-sm text-gray-600">{shipDetails.type}</p>
              )}
            </div>
          </div>

          <div className="space-y-3">
            {Object.entries(shipDetails).map(([key, value]) => {
              if (key === "name" || key === "type") return null
              return (
                <div key={key} className="flex justify-between items-center">
                  <span className="text-gray-600 capitalize">{key}</span>
                  {isEditing ? (
                    <Input
                      name={key}
                      value={value}
                      onChange={handleInputChange}
                      className="w-1/2 text-right"
                    />
                  ) : (
                    <span className="font-medium">{value}</span>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        <div className="rounded-lg bg-white p-4 shadow-sm">
          <h2 className="font-semibold mb-4">Ship Documents</h2>
          <div className="space-y-4">
            {documents.map((doc, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="h-5 w-5 text-gray-400" />
                  {isEditing ? (
                    <Input
                      value={doc.name}
                      onChange={(e) => handleDocumentChange(index, "name", e.target.value)}
                      className="w-full"
                    />
                  ) : (
                    <span>{doc.name}</span>
                  )}
                </div>
                {isEditing ? (
                  <Input
                    type="date"
                    value={doc.expiry}
                    onChange={(e) => handleDocumentChange(index, "expiry", e.target.value)}
                    className="w-40"
                  />
                ) : (
                  <span className="text-sm text-gray-600">Exp: {doc.expiry}</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {isEditing && (
          <Button onClick={handleSave} className="w-full">
            Save Changes
          </Button>
        )}
      </div>

    </main>
  )
}

