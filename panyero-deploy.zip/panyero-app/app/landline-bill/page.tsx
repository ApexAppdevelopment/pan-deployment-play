import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Phone } from 'lucide-react'

export default function LandlineBillPage() {
  return <PlaceholderServicePage title="Landline Bill" icon={Phone} />
}

