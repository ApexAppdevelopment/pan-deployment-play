import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Tv } from 'lucide-react'

export default function TVShowsPage() {
  return <PlaceholderServicePage title="TV Shows" icon={Tv} />
}

