import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Droplet } from 'lucide-react'

export default function WaterBillPage() {
  return <PlaceholderServicePage title="Water Bill" icon={Droplet} />
}

