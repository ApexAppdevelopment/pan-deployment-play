import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Music } from 'lucide-react'

export default function MusicPage() {
  return <PlaceholderServicePage title="Music" icon={Music} />
}

