import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Train } from 'lucide-react'

export default function TrainTicketsPage() {
  return <PlaceholderServicePage title="Train Tickets" icon={Train} />
}

