import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Wifi } from 'lucide-react'

export default function InternetBillPage() {
  return <PlaceholderServicePage title="Internet Bill" icon={Wifi} />
}

