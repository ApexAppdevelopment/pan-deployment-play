import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Utensils } from 'lucide-react'

export default function FoodDeliveryPage() {
  return <PlaceholderServicePage title="Food Delivery" icon={Utensils} />
}

