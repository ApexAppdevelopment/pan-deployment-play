import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Navigation } from 'lucide-react'

export default function NavigatePage() {
  return <PlaceholderServicePage title="Navigation" icon={Navigation} />
}

