import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Smartphone } from "lucide-react"

export default function MobileLoadPage() {
  return <PlaceholderServicePage title="Mobile Load" icon={Smartphone} />
}

