import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Users } from 'lucide-react'

export default function CrewTrackerPage() {
  return <PlaceholderServicePage title="Crew Tracker" icon={Users} />
}

