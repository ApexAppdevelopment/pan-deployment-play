import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Car } from 'lucide-react'

export default function CarRentalPage() {
  return <PlaceholderServicePage title="Car Rental" icon={Car} />
}

