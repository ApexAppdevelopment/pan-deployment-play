import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Ship } from 'lucide-react'

export default function VesselOpPage() {
  return <PlaceholderServicePage title="Vessel Operations" icon={Ship} />
}

