import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { BarChart } from 'lucide-react'

export default function StocksPage() {
  return <PlaceholderServicePage title="Stocks" icon={BarChart} />
}

