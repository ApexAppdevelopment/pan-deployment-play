import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Gift } from 'lucide-react'

export default function VouchersPage() {
  return <PlaceholderServicePage title="Vouchers" icon={Gift} />
}

