import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"

const lotteryGames = [
  { name: "6/49 Lotto", jackpot: "₱50,000,000", drawTime: "9:00 PM" },
  { name: "6/58 Ultra Lotto", jackpot: "₱100,000,000", drawTime: "9:00 PM" },
  { name: "6/42 Lotto", jackpot: "₱25,000,000", drawTime: "9:00 PM" },
  { name: "6/55 Grand Lotto", jackpot: "₱75,000,000", drawTime: "9:00 PM" },
]

export default function LotteryPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="space-y-6 p-4">
        <h1 className="text-2xl font-bold">Lottery</h1>
        
        <div className="grid gap-4">
          {lotteryGames.map((game, index) => (
            <div key={index} className="rounded-lg bg-white p-4 shadow-sm">
              <h2 className="text-lg font-semibold mb-2">{game.name}</h2>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-500">Jackpot:</span>
                <span className="text-green-600 font-bold">{game.jackpot}</span>
              </div>
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm text-gray-500">Draw Time:</span>
                <span>{game.drawTime}</span>
              </div>
              <Button className="w-full">Place Bet</Button>
            </div>
          ))}
        </div>

        <div className="bg-yellow-50 rounded-lg p-4 mt-6">
          <h2 className="text-lg font-semibold mb-2">Responsible Gaming</h2>
          <p className="text-sm text-gray-600">
            Please gamble responsibly. Gambling should be entertaining and not seen as a way to make money. 
            Only gamble with money you can afford to lose.
          </p>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

