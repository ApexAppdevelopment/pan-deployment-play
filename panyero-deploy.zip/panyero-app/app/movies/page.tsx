import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Film } from 'lucide-react'

export default function MoviesPage() {
  return <PlaceholderServicePage title="Movies" icon={Film} />
}

