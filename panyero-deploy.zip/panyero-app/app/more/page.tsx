import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { ServiceIconGrid } from "@/components/service-icon-grid"
import { Banknote, CreditCard, Wallet, ShoppingCart, Ticket, Plane, Car, Train, Hotel, Utensils, Gamepad2, Music, Film, Tv, Gift, Award, Zap, Droplet, Wifi, Phone, Smartphone, Globe, BookOpen, GraduationCap, Briefcase, PiggyBank, BarChart, Shield, HeartPulse, Leaf, Recycle, Anchor, Compass, Ship, LifeBuoy, Radar, Waves, Thermometer, Wind, Navigation, CloudRain, Monitor, Radio, SirenIcon as Sonar, Map, Book, Sunrise, Watch, Mic2, Satellite, PlaneLanding, Users, Gauge, ClipboardCheck, Library, Locate, MessageSquare, AlertTriangle, Timer, School, Wand2, Brain, BotIcon as Robot, Cpu, Code, Image, FileVideo, FileAudio, FileText, Database, BarChartIcon as ChartBar, FileCheck, FileSpreadsheet, FileImage, Search, Languages, MessageCircle, Headphones, PenTool, Fingerprint, Layers, TrendingUp } from 'lucide-react'

const truncateLabel = (label: string) => label.length > 8 ? label.substring(0, 8) + "..." : label;

const serviceCategories = [
  {
    title: "Financial Services",
    icons: [
      { icon: Banknote, label: truncateLabel("Cash In"), href: "/cash-in" },
      { icon: CreditCard, label: truncateLabel("Pay Bills"), href: "/pay-bills" },
      { icon: Wallet, label: truncateLabel("Send Money"), href: "/send-money" },
      { icon: ShoppingCart, label: truncateLabel("QR Payment"), href: "/qr-payment" },
    ]
  },
  {
    title: "Lifestyle",
    icons: [
      { icon: Ticket, label: truncateLabel("Movie Tickets"), href: "/movie-tickets" },
      { icon: Plane, label: truncateLabel("Flights"), href: "/flights" },
      { icon: Car, label: truncateLabel("Car Rental"), href: "/car-rental" },
      { icon: Train, label: truncateLabel("Train Tickets"), href: "/train-tickets" },
      { icon: Hotel, label: truncateLabel("Hotels"), href: "/hotels" },
      { icon: Utensils, label: truncateLabel("Food Delivery"), href: "/food-delivery" },
    ]
  },
  {
    title: "Entertainment",
    icons: [
      { icon: Gamepad2, label: truncateLabel("Games"), href: "/games" },
      { icon: Music, label: truncateLabel("Music"), href: "/music" },
      { icon: Film, label: truncateLabel("Movies"), href: "/movies" },
      { icon: Tv, label: truncateLabel("TV Shows"), href: "/tv-shows" },
    ]
  },
  {
    title: "Rewards & Offers",
    icons: [
      { icon: Gift, label: truncateLabel("Vouchers"), href: "/vouchers" },
      { icon: Award, label: truncateLabel("Loyalty Points"), href: "/loyalty-points" },
    ]
  },
  {
    title: "Utilities",
    icons: [
      { icon: Zap, label: truncateLabel("Electricity"), href: "/electricity-bill" },
      { icon: Droplet, label: truncateLabel("Water"), href: "/water-bill" },
      { icon: Wifi, label: truncateLabel("Internet"), href: "/internet-bill" },
      { icon: Phone, label: truncateLabel("Landline"), href: "/landline-bill" },
      { icon: Smartphone, label: truncateLabel("Mobile Load"), href: "/mobile-load" },
      { icon: Globe, label: truncateLabel("Cable TV"), href: "/cable-tv-bill" },
    ]
  },
  {
    title: "Education",
    icons: [
      { icon: BookOpen, label: truncateLabel("Online Courses"), href: "/online-courses" },
      { icon: GraduationCap, label: truncateLabel("Tuition Fees"), href: "/tuition-fees" },
    ]
  },
  {
    title: "Career",
    icons: [
      { icon: Briefcase, label: truncateLabel("Job Board"), href: "/job-board" },
    ]
  },
  {
    title: "Investments",
    icons: [
      { icon: PiggyBank, label: truncateLabel("Savings"), href: "/savings" },
      { icon: BarChart, label: truncateLabel("Stocks"), href: "/stocks" },
    ]
  },
  {
    title: "Insurance",
    icons: [
      { icon: Shield, label: truncateLabel("Life Insurance"), href: "/life-insurance" },
      { icon: HeartPulse, label: truncateLabel("Health Insurance"), href: "/health-insurance" },
    ]
  },
  {
    title: "Sustainability",
    icons: [
      { icon: Leaf, label: truncateLabel("Green Products"), href: "/green-products" },
      { icon: Recycle, label: truncateLabel("Recycling"), href: "/recycling" },
    ]
  },
  {
    title: "Maritime",
    icons: [
      { icon: Anchor, label: truncateLabel("ShipDock"), href: "/ship-dock" },
      { icon: Compass, label: truncateLabel("NaviTool"), href: "/navi-tool" },
      { icon: Ship, label: truncateLabel("VesselOp"), href: "/vessel-op" },
      { icon: LifeBuoy, label: truncateLabel("SeaSafty"), href: "/sea-safety" },
      { icon: Radar, label: truncateLabel("RadarMap"), href: "/radar-map" },
      { icon: Waves, label: truncateLabel("TideInfo"), href: "/tide-info" },
      { icon: Thermometer, label: truncateLabel("SeaTemp"), href: "/sea-temp" },
      { icon: Wind, label: truncateLabel("WindData"), href: "/wind-data" },
    ]
  },
  {
    title: "Maritime Tools",
    icons: [
      { icon: Navigation, label: truncateLabel("Navigate"), href: "/navigate" },
      { icon: CloudRain, label: truncateLabel("Weather"), href: "/weather" },
      { icon: Monitor, label: truncateLabel("ECDIS"), href: "/ecdis" },
      { icon: Radio, label: truncateLabel("AIS"), href: "/ais" },
      { icon: Radar, label: truncateLabel("Radar"), href: "/radar" },
      { icon: Sonar, label: truncateLabel("Sonar"), href: "/sonar" },
      { icon: Map, label: truncateLabel("ChartPlt"), href: "/chartplotter" },
      { icon: Compass, label: truncateLabel("Compass"), href: "/compass" },
      { icon: Book, label: truncateLabel("Logbook"), href: "/logbook" },
      { icon: Sunrise, label: truncateLabel("Sextant"), href: "/sextant" },
      { icon: Thermometer, label: truncateLabel("Baromtr"), href: "/barometer" },
      { icon: Watch, label: truncateLabel("Chrono"), href: "/chronometer" },
      { icon: Mic2, label: truncateLabel("VHF"), href: "/vhf" },
      { icon: Satellite, label: truncateLabel("GPS"), href: "/gps" },
      { icon: PlaneLanding, label: truncateLabel("AutoPlt"), href: "/autopilot" },
      { icon: ShoppingCart, label: truncateLabel("CargoPln"), href: "/cargo-planner" },
      { icon: Users, label: truncateLabel("CrewTrk"), href: "/crew-tracker" },
      { icon: Gauge, label: truncateLabel("EnginMon"), href: "/engine-monitor" },
      { icon: ClipboardCheck, label: truncateLabel("SafetyChk"), href: "/safety-checklist" },
      { icon: Library, label: truncateLabel("MarLib"), href: "/maritime-library" },
      { icon: Locate, label: truncateLabel("ShipTrk"), href: "/ship-tracker" },
      { icon: MessageSquare, label: truncateLabel("Comms"), href: "/communication" },
      { icon: AlertTriangle, label: truncateLabel("Emergcy"), href: "/emergency" },
      { icon: Timer, label: truncateLabel("TidePred"), href: "/tide-predictor" },
      { icon: School, label: truncateLabel("TrainSim"), href: "/training-simulators" },
    ]
  },
  {
    title: "AI Solutions",
    icons: [
      { icon: Wand2, label: truncateLabel("AI Magic"), href: "/ai/magic-wand" },
      { icon: Brain, label: truncateLabel("AI Assist"), href: "/ai/assistant" },
      { icon: Robot, label: truncateLabel("Automate"), href: "/ai/automation" },
      { icon: Cpu, label: truncateLabel("AI Proc"), href: "/ai/processing" },
      { icon: Code, label: truncateLabel("CodeGen"), href: "/ai/code-gen" },
      { icon: Image, label: truncateLabel("ImgGen"), href: "/ai/image-gen" },
      { icon: FileVideo, label: truncateLabel("VidGen"), href: "/ai/video-gen" },
      { icon: FileAudio, label: truncateLabel("AudioGen"), href: "/ai/audio-gen" },
      { icon: FileText, label: truncateLabel("TextGen"), href: "/ai/text-gen" },
      { icon: Database, label: truncateLabel("DataAnal"), href: "/ai/data-analysis" },
      { icon: ChartBar, label: truncateLabel("PredAnal"), href: "/ai/predictive-analytics" },
      { icon: FileCheck, label: truncateLabel("AIComply"), href: "/ai/compliance" },
      { icon: FileSpreadsheet, label: truncateLabel("AIReport"), href: "/ai/reporting" },
      { icon: FileImage, label: truncateLabel("CompVis"), href: "/ai/computer-vision" },
      { icon: Search, label: truncateLabel("AISearch"), href: "/ai/search" },
      { icon: Languages, label: truncateLabel("AITrans"), href: "/ai/translation" },
      { icon: MessageCircle, label: truncateLabel("AIChat"), href: "/ai/chatbot" },
      { icon: Headphones, label: truncateLabel("AISpeech"), href: "/ai/speech-recognition" },
      { icon: PenTool, label: truncateLabel("AIWrite"), href: "/ai/content-writing" },
      { icon: Fingerprint, label: truncateLabel("AIFraud"), href: "/ai/fraud-detection" },
      { icon: Layers, label: truncateLabel("AIRecomm"), href: "/ai/recommendations" },
      { icon: TrendingUp, label: truncateLabel("AIForec"), href: "/ai/forecasting" },
    ]
  },
]

export default function MorePage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6">More Services</h1>
        <ServiceIconGrid categories={serviceCategories} />
      </div>
      <BottomNav />
    </main>
  )
}

