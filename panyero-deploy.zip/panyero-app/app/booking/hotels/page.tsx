"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Hotel, Calendar, Users } from 'lucide-react'
import { toast } from "sonner"

export default function HotelBookingPage() {
  const [checkinDate, setCheckinDate] = useState("")
  const [checkoutDate, setCheckoutDate] = useState("")
  const [adults, setAdults] = useState("")
  const [destId, setDestId] = useState("")
  const [hotels, setHotels] = useState([])
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch(`/api/booking/hotels?checkin_date=${checkinDate}&checkout_date=${checkoutDate}&adults_number=${adults}&dest_id=${destId}`)
      const data = await response.json()
      if (response.ok) {
        setHotels(data.result)
      } else {
        throw new Error(data.error || "Failed to fetch hotels")
      }
    } catch (error) {
      toast.error("Failed to fetch hotels")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold flex items-center">
          <Hotel className="mr-2 h-6 w-6" />
          Hotel Booking
        </h1>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex space-x-2">
            <div className="flex-1">
              <label htmlFor="checkin" className="block text-sm font-medium text-gray-700">Check-in</label>
              <Input
                id="checkin"
                type="date"
                value={checkinDate}
                onChange={(e) => setCheckinDate(e.target.value)}
                required
              />
            </div>
            <div className="flex-1">
              <label htmlFor="checkout" className="block text-sm font-medium text-gray-700">Check-out</label>
              <Input
                id="checkout"
                type="date"
                value={checkoutDate}
                onChange={(e) => setCheckoutDate(e.target.value)}
                required
              />
            </div>
          </div>
          <div>
            <label htmlFor="adults" className="block text-sm font-medium text-gray-700">Number of Adults</label>
            <Input
              id="adults"
              type="number"
              value={adults}
              onChange={(e) => setAdults(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="destId" className="block text-sm font-medium text-gray-700">Destination ID</label>
            <Input
              id="destId"
              type="text"
              value={destId}
              onChange={(e) => setDestId(e.target.value)}
              required
            />
          </div>
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Searching..." : "Search Hotels"}
          </Button>
        </form>

        {hotels.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Available Hotels</h2>
            {hotels.map((hotel: any) => (
              <Card key={hotel.hotel_id}>
                <CardHeader>
                  <CardTitle>{hotel.hotel_name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Rating: {hotel.review_score}/10</p>
                  <p>Price: ${hotel.min_total_price}</p>
                  <Button className="mt-2">Book Now</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

