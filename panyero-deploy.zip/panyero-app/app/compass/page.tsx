import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Compass } from 'lucide-react'

export default function CompassPage() {
  return <PlaceholderServicePage title="Compass" icon={Compass} />
}

