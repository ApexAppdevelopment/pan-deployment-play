import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { GraduationCap } from 'lucide-react'

export default function TuitionFeesPage() {
  return <PlaceholderServicePage title="Tuition Fees" icon={GraduationCap} />
}

