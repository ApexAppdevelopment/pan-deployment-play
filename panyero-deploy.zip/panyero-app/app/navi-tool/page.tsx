import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Compass } from 'lucide-react'

export default function NaviToolPage() {
  return <PlaceholderServicePage title="Navigation Tool" icon={Compass} />
}

