import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Waves } from 'lucide-react'

export default function TideInfoPage() {
  return <PlaceholderServicePage title="Tide Information" icon={Waves} />
}

