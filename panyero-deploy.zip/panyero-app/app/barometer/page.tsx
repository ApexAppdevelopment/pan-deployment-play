import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Thermometer } from 'lucide-react'

export default function BarometerPage() {
  return <PlaceholderServicePage title="Barometer" icon={Thermometer} />
}

