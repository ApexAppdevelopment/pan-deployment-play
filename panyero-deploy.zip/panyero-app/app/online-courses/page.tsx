import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { BookOpen } from 'lucide-react'

export default function OnlineCoursesPage() {
  return <PlaceholderServicePage title="Online Courses" icon={BookOpen} />
}

