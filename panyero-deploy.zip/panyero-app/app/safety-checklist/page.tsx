import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { ClipboardCheck } from 'lucide-react'

export default function SafetyChecklistPage() {
  return <PlaceholderServicePage title="Safety Checklist" icon={ClipboardCheck} />
}

