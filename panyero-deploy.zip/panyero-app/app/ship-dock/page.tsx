import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Anchor } from 'lucide-react'

export default function ShipDockPage() {
  return <PlaceholderServicePage title="Ship Dock" icon={Anchor} />
}

