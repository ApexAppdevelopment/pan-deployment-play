import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { ShoppingCart } from 'lucide-react'

export default function QRPaymentPage() {
  return <PlaceholderServicePage title="QR Payment" icon={ShoppingCart} />
}

