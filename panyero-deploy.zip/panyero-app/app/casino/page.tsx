"use client"

import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { CasinoGamesList } from "@/components/casino-games-list"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function CasinoPage() {
  const { user } = useAuth()

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Casino Games</h1>
        
        {user ? (
          <CasinoGamesList />
        ) : (
          <div className="text-center py-12">
            <p className="text-lg text-gray-500 mb-4">Please sign in to view and play casino games</p>
            <Button asChild>
              <Link href="/auth/sign-in">Sign In</Link>
            </Button>
          </div>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

