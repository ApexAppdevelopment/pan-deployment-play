"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, Shield, Phone, FileText, LifeBuoy, CheckCircle, XCircle } from 'lucide-react'
import { toast } from "sonner"

const emergencyContacts = [
  { name: "Ship Security Officer", number: "+1234567890" },
  { name: "Medical Officer", number: "+1234567891" },
  { name: "Port Authority", number: "+1234567892" },
]

const safetyDocuments = [
  { title: "Emergency Procedures", updated: "2023-12-01" },
  { title: "Safety Equipment Guide", updated: "2023-11-15" },
  { title: "Evacuation Plan", updated: "2023-12-10" },
]

const safetyEquipment = [
  { name: "Life Jackets", status: "OK", lastChecked: "2023-12-15" },
  { name: "Fire Extinguishers", status: "Needs Inspection", lastChecked: "2023-11-01" },
  { name: "Emergency Flares", status: "OK", lastChecked: "2023-12-10" },
  { name: "First Aid Kits", status: "Needs Restocking", lastChecked: "2023-12-05" },
]

export default function SafetyPage() {
  const [inspectionProgress, setInspectionProgress] = useState(0)

  const startInspection = () => {
    toast.info("Safety inspection started")
    const interval = setInterval(() => {
      setInspectionProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          toast.success("Safety inspection completed")
          return 100
        }
        return prev + 10
      })
    }, 500)
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Safety Center</h1>

        <div className="bg-red-50 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-3">
            <AlertTriangle className="h-6 w-6 text-red-600" />
            <h2 className="font-semibold text-red-600">Emergency Contacts</h2>
          </div>
          <div className="space-y-3">
            {emergencyContacts.map((contact, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-gray-700">{contact.name}</span>
                <Button variant="outline" size="sm">
                  <Phone className="h-4 w-4 mr-2" />
                  Call
                </Button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="h-6 w-6 text-blue-600" />
            <h2 className="font-semibold">Safety Documents</h2>
          </div>
          <div className="space-y-4">
            {safetyDocuments.map((doc, index) => (
              <div key={index} className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">{doc.title}</h3>
                  <p className="text-sm text-gray-500">Updated: {doc.updated}</p>
                </div>
                <Button variant="ghost" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  View
                </Button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <LifeBuoy className="h-6 w-6 text-blue-600" />
            <h2 className="font-semibold">Safety Equipment Check</h2>
          </div>
          <div className="space-y-4">
            {safetyEquipment.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">{item.name}</h3>
                  <p className="text-sm text-gray-500">Last checked: {item.lastChecked}</p>
                </div>
                <div className="flex items-center">
                  {item.status === "OK" ? (
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500 mr-2" />
                  )}
                  <span className={item.status === "OK" ? "text-green-500" : "text-red-500"}>
                    {item.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4">
            <Button className="w-full" onClick={startInspection}>
              Start Safety Inspection
            </Button>
            {inspectionProgress > 0 && (
              <div className="mt-4">
                <Progress value={inspectionProgress} className="w-full" />
                <p className="text-center mt-2">Inspection Progress: {inspectionProgress}%</p>
              </div>
            )}
          </div>
        </div>
      </div>

    </main>
  )
}

