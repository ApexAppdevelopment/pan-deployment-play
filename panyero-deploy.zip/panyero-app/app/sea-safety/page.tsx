import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { LifeBuoy } from 'lucide-react'

export default function SeaSafetyPage() {
  return <PlaceholderServicePage title="Sea Safety" icon={LifeBuoy} />
}

