import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { School } from 'lucide-react'

export default function TrainingSimulatorsPage() {
  return <PlaceholderServicePage title="Training Simulators" icon={School} />
}

