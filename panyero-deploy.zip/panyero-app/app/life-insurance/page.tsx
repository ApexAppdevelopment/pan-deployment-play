import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Shield } from 'lucide-react'

export default function LifeInsurancePage() {
  return <PlaceholderServicePage title="Life Insurance" icon={Shield} />
}

