"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Wand2 } from 'lucide-react'
import { toast } from "sonner"

export default function MagicWandPage() {
  const [prompt, setPrompt] = useState("")
  const [result, setResult] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch("/api/ai/magic-wand", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      })
      const data = await response.json()
      if (response.ok) {
        setResult(data.result)
      } else {
        throw new Error(data.error || "Something went wrong")
      }
    } catch (error) {
      toast.error("Failed to generate content")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold flex items-center">
          <Wand2 className="mr-2 h-6 w-6" />
          AI Magic Wand
        </h1>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            placeholder="Enter your prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            required
          />
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Generating..." : "Generate"}
          </Button>
        </form>

        {result && (
          <div className="mt-6">
            <h2 className="text-lg font-semibold mb-2">Result:</h2>
            <Textarea value={result} readOnly className="h-40" />
          </div>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

