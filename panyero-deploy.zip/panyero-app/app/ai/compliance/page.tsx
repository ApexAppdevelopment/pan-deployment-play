"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileCheck, Loader2, AlertTriangle, CheckCircle } from 'lucide-react'
import { toast } from "sonner"

const complianceStandards = [
  { id: "gdpr", name: "GDPR" },
  { id: "hipaa", name: "HIPAA" },
  { id: "pci-dss", name: "PCI DSS" },
  { id: "iso27001", name: "ISO 27001" },
]

export default function AICompliancePage() {
  const [text, setText] = useState("")
  const [standard, setStandard] = useState(complianceStandards[0].id)
  const [result, setResult] = useState<{ compliant: boolean; details: string } | null>(null)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch("/api/ai/compliance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, standard }),
      })
      const data = await response.json()
      if (response.ok) {
        setResult(data)
        toast.success("Compliance check completed!")
      } else {
        throw new Error(data.error || "Something went wrong")
      }
    } catch (error) {
      toast.error("Failed to perform compliance check")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold flex items-center">
          <FileCheck className="mr-2 h-6 w-6" />
          AI Compliance Checker
        </h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Check Compliance</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Textarea
                placeholder="Enter text to check for compliance"
                value={text}
                onChange={(e) => setText(e.target.value)}
                required
                className="h-32"
              />
              <Select value={standard} onValueChange={setStandard}>
                <SelectTrigger>
                  <SelectValue placeholder="Select compliance standard" />
                </SelectTrigger>
                <SelectContent>
                  {complianceStandards.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button type="submit" disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Checking Compliance...
                  </>
                ) : (
                  "Check Compliance"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {result && (
          <Card>
            <CardHeader>
              <CardTitle>Compliance Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`flex items-center ${result.compliant ? 'text-green-600' : 'text-red-600'} mb-4`}>
                {result.compliant ? (
                  <CheckCircle className="mr-2 h-6 w-6" />
                ) : (
                  <AlertTriangle className="mr-2 h-6 w-6" />
                )}
                <span className="font-semibold">
                  {result.compliant ? 'Compliant' : 'Non-Compliant'}
                </span>
              </div>
              <div className="whitespace-pre-wrap">{result.details}</div>
            </CardContent>
          </Card>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

