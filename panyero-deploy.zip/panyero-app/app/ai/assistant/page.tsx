import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Brain } from 'lucide-react'

export default function AIAssistantPage() {
  return <PlaceholderServicePage title="AI Assistant" icon={Brain} />
}

