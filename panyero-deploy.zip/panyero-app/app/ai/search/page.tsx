"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, Loader2 } from 'lucide-react'
import { toast } from "sonner"

interface SearchResult {
  title: string
  snippet: string
  link: string
}

export default function AISearchPage() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch(`/api/ai/search?q=${encodeURIComponent(query)}`)
      const data = await response.json()
      if (response.ok) {
        setResults(data.results)
        toast.success("Search completed!")
      } else {
        throw new Error(data.error || "Something went wrong")
      }
    } catch (error) {
      toast.error("Failed to perform search")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold flex items-center">
          <Search className="mr-2 h-6 w-6" />
          AI-Powered Search
        </h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Search</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                placeholder="Enter your search query"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                required
              />
              <Button type="submit" disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Searching...
                  </>
                ) : (
                  "Search"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {results.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Search Results</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                {results.map((result, index) => (
                  <li key={index} className="border-b pb-4 last:border-b-0 last:pb-0">
                    <h3 className="text-lg font-semibold">
                      <a href={result.link} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                        {result.title}
                      </a>
                    </h3>
                    <p className="text-sm text-gray-600">{result.snippet}</p>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

