"use server"

import { revalidatePath } from "next/cache"
import { placeBet as placeBetService } from "@/lib/wallet-service"
import { auth, getWallet } from "@/lib/auth"

export async function placeBet(
  gameId: string,
  outcome: string,
  amount: number,
  odds: number
) {
  try {
    const user = auth().currentUser
    if (!user) {
      return { success: false, error: 'User not authenticated' }
    }

    const wallet = await getWallet(user.uid)
    if (!wallet) {
      return { success: false, error: 'Wallet not found' }
    }

    if (wallet.balance < amount) {
      return { success: false, error: 'Insufficient funds' }
    }

    const result = await placeBetService(gameId, outcome, amount, odds)
    revalidatePath('/games')
    return { success: true, ...result }
  } catch (error) {
    console.error('Error placing bet:', error)
    return { success: false, error: 'Failed to place bet' }
  }
}

