"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"
import { Bell, Moon, Globe } from 'lucide-react'

export default function PreferencesPage() {
  const { user, supabase } = useAuth()
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
  })
  const [darkMode, setDarkMode] = useState(false)
  const [language, setLanguage] = useState("en")
  const [loading, setLoading] = useState(false)

  const handleNotificationChange = (type: keyof typeof notifications) => {
    setNotifications(prev => ({ ...prev, [type]: !prev[type] }))
  }

  const handleSavePreferences = async () => {
    try {
      setLoading(true)
      // Here you would typically call an API to save the user's preferences
      // For this example, we'll just simulate an API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      toast.success("Preferences saved successfully")
    } catch (error) {
      console.error("Error saving preferences:", error)
      toast.error("Failed to save preferences")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6">Preferences</h1>

        <div className="space-y-6">
          <div className="bg-white p-4 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">Notifications</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="emailNotifications" className="flex items-center">
                  <Bell className="h-5 w-5 mr-2" />
                  Email Notifications
                </Label>
                <Switch
                  id="emailNotifications"
                  checked={notifications.email}
                  onCheckedChange={() => handleNotificationChange('email')}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="pushNotifications" className="flex items-center">
                  <Bell className="h-5 w-5 mr-2" />
                  Push Notifications
                </Label>
                <Switch
                  id="pushNotifications"
                  checked={notifications.push}
                  onCheckedChange={() => handleNotificationChange('push')}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="smsNotifications" className="flex items-center">
                  <Bell className="h-5 w-5 mr-2" />
                  SMS Notifications
                </Label>
                <Switch
                  id="smsNotifications"
                  checked={notifications.sms}
                  onCheckedChange={() => handleNotificationChange('sms')}
                />
              </div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">Appearance</h2>
            <div className="flex items-center justify-between">
              <Label htmlFor="darkMode" className="flex items-center">
                <Moon className="h-5 w-5 mr-2" />
                Dark Mode
              </Label>
              <Switch
                id="darkMode"
                checked={darkMode}
                onCheckedChange={setDarkMode}
              />
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">Language</h2>
            <div className="flex items-center">
              <Globe className="h-5 w-5 mr-2" />
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a language" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="de">Deutsch</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            className="w-full"
            onClick={handleSavePreferences}
            disabled={loading}
          >
            {loading ? "Saving..." : "Save Preferences"}
          </Button>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

