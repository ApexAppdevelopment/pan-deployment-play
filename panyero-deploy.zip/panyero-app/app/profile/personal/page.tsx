"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"

export default function PersonalInformationPage() {
  const { user, supabase } = useAuth()
  const [fullName, setFullName] = useState(user?.user_metadata?.full_name || "")
  const [phoneNumber, setPhoneNumber] = useState(user?.user_metadata?.phone_number || "")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      setLoading(true)
      const { error } = await supabase.auth.updateUser({
        data: { full_name: fullName, phone_number: phoneNumber }
      })
      if (error) throw error
      toast.success("Personal information updated successfully")
    } catch (error) {
      console.error("Error updating personal information:", error)
      toast.error("Failed to update personal information")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6">Personal Information</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="fullName">Full Name</Label>
            <Input
              id="fullName"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={user?.email || ""}
              disabled
            />
          </div>

          <div>
            <Label htmlFor="phoneNumber">Phone Number</Label>
            <Input
              id="phoneNumber"
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
            />
          </div>

          <Button
            type="submit"
            className="w-full"
            disabled={loading}
          >
            {loading ? "Updating..." : "Update Information"}
          </Button>
        </form>
      </div>

      <BottomNav />
    </main>
  )
}

