"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import { Lock, Smartphone } from 'lucide-react'

export default function SecurityPage() {
  const { user, supabase } = useAuth()
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false)

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match")
      return
    }
    try {
      setLoading(true)
      const { error } = await supabase.auth.updateUser({ password: newPassword })
      if (error) throw error
      toast.success("Password updated successfully")
      setNewPassword("")
      setConfirmPassword("")
    } catch (error) {
      console.error("Error updating password:", error)
      toast.error("Failed to update password")
    } finally {
      setLoading(false)
    }
  }

  const handleToggleTwoFactor = async () => {
    // Here you would typically integrate with your backend to enable/disable 2FA
    setTwoFactorEnabled(!twoFactorEnabled)
    toast.success(`Two-factor authentication ${twoFactorEnabled ? 'disabled' : 'enabled'}`)
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6">Security Settings</h1>

        <div className="space-y-6">
          <div className="bg-white p-4 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">Change Password</h2>
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div>
                <Label htmlFor="newPassword">New Password</Label>
                <Input
                  id="newPassword"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="confirmPassword">Confirm New Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={loading}
              >
                {loading ? "Updating..." : "Update Password"}
              </Button>
            </form>
          </div>

          <div className="bg-white p-4 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">Two-Factor Authentication</h2>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Smartphone className="h-6 w-6 mr-2 text-gray-500" />
                <span>{twoFactorEnabled ? "Enabled" : "Disabled"}</span>
              </div>
              <Button onClick={handleToggleTwoFactor}>
                {twoFactorEnabled ? "Disable" : "Enable"}
              </Button>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">Recent Login Activity</h2>
            <p className="text-sm text-gray-600">
              Last login: {new Date().toLocaleString()}
            </p>
            <Button className="mt-4 w-full">View Full Activity Log</Button>
          </div>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

