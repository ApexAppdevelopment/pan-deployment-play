"use client"

import { useState, useEffect } from 'react'
import { useMapbox } from '@/hooks/use-mapbox'
import { fetchPorts } from '@/services/port-service'
import * as turf from '@turf/turf'
import { StickyHeader } from "@/components/ui/sticky-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Navigation } from 'lucide-react'

const MAPBOX_ACCESS_TOKEN = 'pk.eyJ1Ijoia2llcm9kZWVhaXRlazI0IiwiYSI6ImNtNDRjZzdqcjA1Z2wyaXEwZm1iYzB1MnMifQ.Ewkk6JoQWicXDki4jcP85w'

interface Port {
  id: string
  name: string
  coordinates: [number, number]
}

const RoutePlanningPage = () => {
  const { map, viewport, setViewport } = useMapbox(MAPBOX_ACCESS_TOKEN)
  const [startPort, setStartPort] = useState<Port | null>(null)
  const [endPort, setEndPort] = useState<Port | null>(null)
  const [route, setRoute] = useState<any>(null)
  const [ports, setPorts] = useState<Port[]>([])

  useEffect(() => {
    const loadPorts = async () => {
      const fetchedPorts = await fetchPorts()
      setPorts(fetchedPorts)
    }
    loadPorts()
  }, [])

  const handlePortSelect = (portType: 'start' | 'end', port: Port) => {
    if (portType === 'start') {
      setStartPort(port)
    } else {
      setEndPort(port)
    }

    if (map) {
      map.flyTo({
        center: port.coordinates,
        zoom: 8
      })
    }
  }

  const calculateRoute = () => {
    if (startPort && endPort && map) {
      const line = turf.lineString([startPort.coordinates, endPort.coordinates])
      const curved = turf.bezierSpline(line)
      setRoute(curved)

      const bounds = turf.bbox(curved)
      map.fitBounds(bounds as [number, number, number, number], { padding: 100 })

      if (!map.getSource('route')) {
        map.addSource('route', {
          type: 'geojson',
          data: curved
        })
        map.addLayer({
          id: 'route',
          type: 'line',
          source: 'route',
          layout: {
            'line-join': 'round',
            'line-cap': 'round'
          },
          paint: {
            'line-color': '#007cbf',
            'line-width': 5,
            'line-opacity': 0.75
          }
        })
      } else {
        (map.getSource('route') as mapboxgl.GeoJSONSource).setData(curved)
      }
    }
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <StickyHeader />
      
      <div className="p-4 space-y-4">
        <h1 className="text-2xl font-bold">Maritime Route Planning</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Plan Your Route</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-green-500" />
              <Input 
                placeholder="Start port" 
                value={startPort?.name || ''}
                onChange={(e) => {
                  const port = ports.find(p => p.name.toLowerCase().includes(e.target.value.toLowerCase()))
                  if (port) handlePortSelect('start', port)
                }}
                list="start-ports"
              />
              <datalist id="start-ports">
                {ports.map(port => (
                  <option key={`start-${port.id}`} value={port.name} />
                ))}
              </datalist>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-red-500" />
              <Input 
                placeholder="Destination port" 
                value={endPort?.name || ''}
                onChange={(e) => {
                  const port = ports.find(p => p.name.toLowerCase().includes(e.target.value.toLowerCase()))
                  if (port) handlePortSelect('end', port)
                }}
                list="end-ports"
              />
              <datalist id="end-ports">
                {ports.map(port => (
                  <option key={`end-${port.id}`} value={port.name} />
                ))}
              </datalist>
            </div>
            <Button onClick={calculateRoute} className="w-full">
              <Navigation className="mr-2 h-4 w-4" /> Calculate Route
            </Button>
          </CardContent>
        </Card>

        <div id="map-container" className="h-[60vh] rounded-lg overflow-hidden" />

        {route && (
          <Card>
            <CardHeader>
              <CardTitle>Route Information</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Distance: {turf.length(route).toFixed(2)} nautical miles</p>
              <p>Estimated travel time: {(turf.length(route) / 20).toFixed(2)} hours (at 20 knots)</p>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  )
}

export default RoutePlanningPage

