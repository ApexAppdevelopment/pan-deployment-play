"use client"

import { useState, useEffect } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Waves } from 'lucide-react'

export default function TidesPage() {
  const [tideLevel, setTideLevel] = useState(0)
  const [tideStatus, setTideStatus] = useState<"rising" | "falling">("rising")

  useEffect(() => {
    // Simulate tide changes
    const interval = setInterval(() => {
      setTideLevel((prevLevel) => {
        const newLevel = prevLevel + (tideStatus === "rising" ? 0.1 : -0.1)
        if (newLevel >= 10) setTideStatus("falling")
        if (newLevel <= 0) setTideStatus("rising")
        return Math.max(0, Math.min(10, newLevel))
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [tideStatus])

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-4">
        <h1 className="text-2xl font-bold">Tide Information</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Current Tide Level</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative h-40 bg-blue-100 rounded-lg overflow-hidden">
              <div 
                className="absolute bottom-0 left-0 right-0 bg-blue-500 transition-all duration-1000"
                style={{ height: `${tideLevel * 10}%` }}
              ></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Waves className="text-blue-700 h-12 w-12" />
              </div>
            </div>
            <div className="mt-4 text-center">
              <p className="text-2xl font-bold">{tideLevel.toFixed(1)} meters</p>
              <p className="text-gray-600">Tide is currently {tideStatus}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

