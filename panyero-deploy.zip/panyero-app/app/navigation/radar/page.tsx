"use client"

import { useState, useEffect } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Radar } from 'lucide-react'

export default function RadarPage() {
  const [vessels, setVessels] = useState<{ x: number; y: number; size: number }[]>([])

  useEffect(() => {
    // Simulate radar detections
    const interval = setInterval(() => {
      const newVessels = Array(5).fill(0).map(() => ({
        x: Math.random() * 200 - 100,
        y: Math.random() * 200 - 100,
        size: Math.random() * 10 + 5
      }))
      setVessels(newVessels)
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-4">
        <h1 className="text-2xl font-bold">Radar Display</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Surrounding Vessels</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative w-full h-64 bg-black rounded-full overflow-hidden">
              <div className="absolute top-1/2 left-1/2 w-1 h-1 bg-green-500 rounded-full"></div>
              {vessels.map((vessel, index) => (
                <div
                  key={index}
                  className="absolute bg-green-500 rounded-full"
                  style={{
                    width: `${vessel.size}px`,
                    height: `${vessel.size}px`,
                    left: `${50 + vessel.x / 2}%`,
                    top: `${50 + vessel.y / 2}%`,
                  }}
                ></div>
              ))}
              <div className="absolute inset-0 flex items-center justify-center">
                <Radar className="w-full h-full text-green-500 opacity-10 animate-spin" style={{ animationDuration: '4s' }} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

