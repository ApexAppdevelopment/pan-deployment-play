"use client"

import { useState, useEffect } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Cloud, Sun, Wind, Droplets } from 'lucide-react'

export default function WeatherPage() {
  const [weather, setWeather] = useState({
    temperature: 0,
    humidity: 0,
    windSpeed: 0,
    description: ""
  })

  useEffect(() => {
    // In a real application, you would fetch this data from a weather API
    // For this example, we'll simulate an API call
    setTimeout(() => {
      setWeather({
        temperature: 25,
        humidity: 60,
        windSpeed: 15,
        description: "Partly cloudy"
      })
    }, 1000)
  }, [])

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-4">
        <h1 className="text-2xl font-bold">Weather Updates</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Current Weather</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Sun className="h-8 w-8 text-yellow-500 mr-2" />
                <span className="text-2xl font-bold">{weather.temperature}°C</span>
              </div>
              <span>{weather.description}</span>
            </div>
            <div className="flex justify-between text-sm">
              <div className="flex items-center">
                <Wind className="h-5 w-5 mr-1" /> {weather.windSpeed} km/h
              </div>
              <div className="flex items-center">
                <Droplets className="h-5 w-5 mr-1" /> {weather.humidity}%
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

