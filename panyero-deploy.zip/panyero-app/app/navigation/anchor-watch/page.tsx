"use client"

import { useState, useEffect } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Anchor, AlertTriangle } from 'lucide-react'

export default function AnchorWatchPage() {
  const [isAnchored, setIsAnchored] = useState(false)
  const [anchorPosition, setAnchorPosition] = useState({ lat: 0, lon: 0 })
  const [currentPosition, setCurrentPosition] = useState({ lat: 0, lon: 0 })
  const [distance, setDistance] = useState(0)

  useEffect(() => {
    if (isAnchored) {
      // Simulate position updates
      const interval = setInterval(() => {
        setCurrentPosition({
          lat: anchorPosition.lat + (Math.random() - 0.5) * 0.0001,
          lon: anchorPosition.lon + (Math.random() - 0.5) * 0.0001
        })
      }, 5000)

      return () => clearInterval(interval)
    }
  }, [isAnchored, anchorPosition])

  useEffect(() => {
    if (isAnchored) {
      // Calculate distance from anchor (simplified)
      const dx = currentPosition.lat - anchorPosition.lat
      const dy = currentPosition.lon - anchorPosition.lon
      setDistance(Math.sqrt(dx * dx + dy * dy) * 111000) // Approximate meters
    }
  }, [isAnchored, currentPosition, anchorPosition])

  const toggleAnchor = () => {
    if (!isAnchored) {
      // Set anchor position to current position
      setAnchorPosition({ ...currentPosition })
    }
    setIsAnchored(!isAnchored)
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-4">
        <h1 className="text-2xl font-bold">Anchor Watch</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Anchor Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button onClick={toggleAnchor} className="w-full">
              <Anchor className="mr-2 h-4 w-4" />
              {isAnchored ? "Weigh Anchor" : "Drop Anchor"}
            </Button>
            {isAnchored && (
              <div>
                <p>Distance from anchor: {distance.toFixed(2)} meters</p>
                {distance > 50 && (
                  <div className="flex items-center text-red-500 mt-2">
                    <AlertTriangle className="mr-2 h-4 w-4" />
                    <span>Warning: Drifting from anchor position!</span>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

