"use client"

import { useAuth } from "@/contexts/auth-context"
import { BackgroundCarousel } from '@/components/background-carousel'
import { AuthButtons } from '@/components/auth-buttons'
import { FloatingAssistant } from '@/components/floating-assistant'
import { LoggedInView } from '@/components/logged-in-view'

export default function Home() {
  const { user } = useAuth()

  return (
    <main className="flex min-h-screen flex-col items-center justify-between relative overflow-hidden">
      <BackgroundCarousel />
      <div className="w-full h-full flex flex-col justify-between z-10 px-6 py-12">
        {user ? (
          <LoggedInView />
        ) : (
          <>
            <AuthButtons />
          </>
        )}
      </div>
      <FloatingAssistant />
    </main>
  )
}

