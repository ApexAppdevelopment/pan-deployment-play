import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Mic2 } from 'lucide-react'

export default function VHFPage() {
  return <PlaceholderServicePage title="VHF Radio" icon={Mic2} />
}

