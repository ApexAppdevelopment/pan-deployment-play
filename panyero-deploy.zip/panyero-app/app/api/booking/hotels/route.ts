import { NextResponse } from 'next/server'

const API_KEY = process.env.RAPIDAPI_KEY;
const API_HOST = 'booking-com.p.rapidapi.com';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const checkin_date = searchParams.get('checkin_date')
  const checkout_date = searchParams.get('checkout_date')
  const adults_number = searchParams.get('adults_number')
  const dest_id = searchParams.get('dest_id')

  try {
    const response = await fetch(`https://${API_HOST}/v1/hotels/search?checkin_date=${checkin_date}&checkout_date=${checkout_date}&adults_number=${adults_number}&dest_id=${dest_id}&units=metric&order_by=popularity&filter_by_currency=USD&locale=en-gb&room_number=1`, {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': API_KEY!,
        'X-RapidAPI-Host': API_HOST
      }
    });

    const data = await response.json();
    
    return NextResponse.json(data);
  } catch (error) {
    console.error('Error in hotel booking API:', error)
    return NextResponse.json({ error: 'Failed to fetch hotel data' }, { status: 500 })
  }
}

