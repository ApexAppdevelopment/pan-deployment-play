import { NextResponse } from 'next/server'
import Replicate from "replicate"

const replicate = new Replicate({
  auth: process.env.REPLICATE_API_TOKEN,
})

export async function POST(req: Request) {
  try {
    const { prompt } = await req.json()

    const output = await replicate.run(
      "stability-ai/stable-diffusion:db21e45d3f7023abc2a46ee38a23973f6dce16bb082a930b0c49861f96d1e5bf",
      {
        input: {
          prompt: prompt,
        }
      }
    )

    return NextResponse.json({ imageUrl: output[0] })
  } catch (error) {
    console.error('Error in image-gen API:', error)
    return NextResponse.json({ error: 'Failed to generate image' }, { status: 500 })
  }
}

