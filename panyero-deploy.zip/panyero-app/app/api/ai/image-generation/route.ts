import { NextResponse } from 'next/server'

const API_KEY = process.env.RAPIDAPI_KEY;
const API_HOST = 'openai80.p.rapidapi.com';

export async function POST(req: Request) {
  try {
    const { prompt } = await req.json()

    const response = await fetch(`https://${API_HOST}/images/generations`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'X-RapidAPI-Key': API_KEY!,
        'X-RapidAPI-Host': API_HOST
      },
      body: JSON.stringify({
        prompt,
        n: 1,
        size: '1024x1024'
      })
    });

    const data = await response.json();
    
    return NextResponse.json({ imageUrl: data.data[0].url });
  } catch (error) {
    console.error('Error in image-generation API:', error)
    return NextResponse.json({ error: 'Failed to generate image' }, { status: 500 })
  }
}

