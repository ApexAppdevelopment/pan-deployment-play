import { NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(req: Request) {
  try {
    const { historicalData, predictionPeriod } = await req.json()

    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: "You are a predictive analytics expert. Generate predictions based on historical data." },
        { role: "user", content: `Generate predictions for the next ${predictionPeriod} days based on this historical data: ${historicalData}` }
      ],
    })

    const prediction = completion.choices[0].message.content

    return NextResponse.json({ prediction })
  } catch (error) {
    console.error('Error in predictive-analytics API:', error)
    return NextResponse.json({ error: 'Failed to generate prediction' }, { status: 500 })
  }
}

