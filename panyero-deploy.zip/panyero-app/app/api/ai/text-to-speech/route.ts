import { NextResponse } from 'next/server'

const API_KEY = process.env.RAPIDAPI_KEY;
const API_HOST = 'text-to-speech-neural-google.p.rapidapi.com';

export async function POST(req: Request) {
  try {
    const { text, voice } = await req.json()

    const response = await fetch(`https://${API_HOST}/synthesize`, {
      method: 'POST',
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
        'X-RapidAPI-Key': API_KEY!,
        'X-RapidAPI-Host': API_HOST
      },
      body: new URLSearchParams({
        text,
        voice
      })
    });

    const audioData = await response.arrayBuffer();
    
    return new NextResponse(audioData, {
      headers: {
        'Content-Type': 'audio/mpeg',
      },
    });
  } catch (error) {
    console.error('Error in text-to-speech API:', error)
    return NextResponse.json({ error: 'Failed to generate speech' }, { status: 500 })
  }
}

