import { NextResponse } from 'next/server'

const API_KEY = '71a409ec33mshfda6f87481c16f1p16995bjsnc0e7372fc0ae'
const API_HOST = 'betfair-sports-casino-live-tv-result-odds.p.rapidapi.com'

export async function GET() {
  const url = `https://${API_HOST}/api/GetMarketIdsV2?market_id=1.226888545`

  const options = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': API_KEY,
      'X-RapidAPI-Host': API_HOST,
    }
  }

  try {
    const response = await fetch(url, options)
    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error('Error fetching Betfair data:', error)
    return NextResponse.json({ error: 'Failed to fetch Betfair data' }, { status: 500 })
  }
}

