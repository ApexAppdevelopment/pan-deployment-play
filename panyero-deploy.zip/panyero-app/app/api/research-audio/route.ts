import { NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

const TAVILY_API_KEY = process.env.TAVILY_API_KEY
const NEETS_API_KEY = 'c3ba3d564bb4405985fa937d7c382426'

async function fetchResearchData(query: string) {
  const response = await fetch('https://api.tavily.com/search', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': TAVILY_API_KEY!,
    },
    body: JSON.stringify({
      query: query,
      search_depth: 'advanced',
      include_domains: [],
      exclude_domains: [],
      max_results: 10,
    }),
  })

  if (!response.ok) {
    throw new Error('Failed to fetch research data')
  }

  return response.json()
}

async function chunkText(text: string): Promise<string[]> {
  const completion = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      { role: "system", content: "You are a helpful assistant that chunks text into approximately 5-minute reading segments." },
      { role: "user", content: `Please chunk the following text into approximately 5-minute reading segments: ${text}` }
    ],
  })

  const chunkedText = completion.choices[0].message.content
  return chunkedText ? chunkedText.split('\n\n') : []
}

async function convertToAudio(text: string): Promise<Blob> {
  const response = await fetch('https://api.neets.ai/v1/tts', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': NEETS_API_KEY,
    },
    body: JSON.stringify({
      text: text,
      voice_id: 'us-male-2',
      params: {
        model: 'style-diff-500'
      }
    }),
  })

  if (!response.ok) {
    throw new Error('Failed to convert text to audio')
  }

  return response.blob()
}

export async function POST(req: Request) {
  try {
    const { query } = await req.json()
    const researchData = await fetchResearchData(query)
    const fullText = researchData.results.map((result: any) => result.content).join(' ')
    const chunks = await chunkText(fullText)

    const audioChunks = await Promise.all(chunks.map(convertToAudio))
    const audioUrls = audioChunks.map(blob => URL.createObjectURL(blob))

    return NextResponse.json({ audioUrls })
  } catch (error) {
    console.error('Error in research-audio API:', error)
    return NextResponse.json({ error: 'Failed to process research and generate audio' }, { status: 500 })
  }
}

