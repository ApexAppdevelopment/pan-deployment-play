import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { BetfairGamesList } from "@/components/betfair-games-list"

export default function GamesPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Betfair Games</h1>
        <BetfairGamesList />
      </div>

      <BottomNav />
    </main>
  )
}

