import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Globe } from 'lucide-react'

export default function CableTVBillPage() {
  return <PlaceholderServicePage title="Cable TV Bill" icon={Globe} />
}

