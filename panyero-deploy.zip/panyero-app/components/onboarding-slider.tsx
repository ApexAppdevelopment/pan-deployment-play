"use client"

import { useState } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const slides = [
  {
    title: "Manage Your Finances at Sea",
    description: "Keep track of your earnings, expenses, and remittances with our powerful digital wallet designed for seafarers.",
    image: "/assets/images/onboarding/finance-management.jpg"
  },
  {
    title: "Stay Connected with Loved Ones",
    description: "Send money home, chat with family, and share your journey with our integrated communication tools.",
    image: "/assets/images/onboarding/stay-connected.jpg"
  },
  {
    title: "Navigate Your Career",
    description: "Access training materials, certification tracking, and job opportunities tailored for maritime professionals.",
    image: "/assets/images/onboarding/career-navigation.jpg"
  }
]

export function OnboardingSlider() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const router = useRouter()

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? prev : prev + 1))
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? prev : prev - 1))
  }

  const goToAuth = () => {
    router.push('/auth/sign-in')
  }

  return (
    <div className="relative h-screen w-full overflow-hidden bg-gray-100">
      <div 
        className="flex h-full transition-transform duration-300 ease-in-out"
        style={{ transform: `translateX(-${currentSlide * 100}%)` }}
      >
        {slides.map((slide, index) => (
          <div key={index} className="flex flex-col items-center justify-center w-full h-full flex-shrink-0 px-6">
            <Image
              src="/assets/images/logo/logo-1024px.png"
              alt="Panyero Logo"
              width={120}
              height={120}
              className="mb-6"
            />
            <div className="relative w-full h-64 mb-8">
              <Image
                src={slide.image}
                alt={slide.title}
                layout="fill"
                objectFit="cover"
                className="rounded-lg shadow-lg"
              />
            </div>
            <h2 className="text-3xl font-bold text-center mb-4">{slide.title}</h2>
            <p className="text-center text-gray-600 mb-8 max-w-md">{slide.description}</p>
          </div>
        ))}
      </div>

      <div className="absolute bottom-10 left-0 right-0 flex justify-center items-center space-x-4">
        {slides.map((_, index) => (
          <button
            key={index}
            className={cn(
              "w-3 h-3 rounded-full transition-colors duration-300",
              currentSlide === index ? "bg-blue-600" : "bg-gray-300"
            )}
            onClick={() => setCurrentSlide(index)}
          />
        ))}
      </div>

      <div className="absolute bottom-20 left-0 right-0 flex justify-center">
        <Button onClick={goToAuth} className="px-8 py-2">
          {currentSlide === slides.length - 1 ? "Get Started" : "Skip"}
        </Button>
      </div>

      <button
        className="absolute top-1/2 left-4 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-md"
        onClick={prevSlide}
        disabled={currentSlide === 0}
      >
        <ChevronLeft className="w-6 h-6 text-gray-600" />
      </button>

      <button
        className="absolute top-1/2 right-4 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-md"
        onClick={nextSlide}
        disabled={currentSlide === slides.length - 1}
      >
        <ChevronRight className="w-6 h-6 text-gray-600" />
      </button>
    </div>
  )
}

