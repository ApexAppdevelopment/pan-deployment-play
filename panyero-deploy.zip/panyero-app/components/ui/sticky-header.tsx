"use client"

import { cn } from "@/lib/utils"
import { Bell, HelpCircle } from 'lucide-react'
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const tabs = [
  { label: "Wallet", href: "/" },
  { label: "Ship Info", href: "/ship-info" },
  { label: "Navigation", href: "/navigation" },
  { label: "Review", href: "/review-center" },
  { label: "Safety", href: "/safety" },
]

export function StickyHeader() {
  const pathname = usePathname()
  const { user } = useAuth()
  const signOut = () => {
    // Add your sign-out logic here
    console.log("Signing out...");
  };
  return (
    <header className="sticky top-0 z-50 w-full bg-white">
      <div className="flex items-center justify-between px-4 py-2">
        {user ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Avatar className="h-8 w-8 cursor-pointer">
                <AvatarImage src={user.photoURL || ""} alt={user.displayName || "User"} />
                <AvatarFallback>{user.displayName?.[0] || "U"}</AvatarFallback>
              </Avatar>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/profile">Profile</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/wallet">Wallet</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings">Settings</Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => signOut()}>
                Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <Link href="/auth/sign-in">
            <Button variant="ghost" size="sm">Sign In</Button>
          </Link>
        )}
        <div className="flex gap-4">
          <Link href="/help">
            <HelpCircle className="h-6 w-6 text-gray-600" />
          </Link>
          <Link href="/notifications">
            <div className="relative">
              <Bell className="h-6 w-6 text-gray-600" />
              <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-green-600 text-[10px] text-white">
                86
              </span>
            </div>
          </Link>
        </div>
      </div>
      <div className="flex gap-4 overflow-x-auto px-4 pb-2">
        {tabs.map((tab) => (
          <Link
            key={tab.href}
            href={tab.href}
            className={cn(
              "min-w-fit rounded-full px-4 py-1 text-sm font-medium",
              pathname === tab.href ? "bg-black text-white" : "text-gray-600"
            )}
          >
            {tab.label}
          </Link>
        ))}
      </div>
    </header>
  )
}

