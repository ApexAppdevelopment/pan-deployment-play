import { cn } from "@/lib/utils"

interface Transaction {
  id: string
  type: string
  description: string
  amount: number
  date: string
}

interface TransactionListProps {
  transactions: Transaction[]
}

export function TransactionList({ transactions }: TransactionListProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Transactions</h2>
        <a href="/transactions" className="text-sm text-green-600">
          See all
        </a>
      </div>
      <div className="space-y-4">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="space-y-1">
            <div className="text-sm text-gray-500">
              {transaction.type}
            </div>
            <div className="flex justify-between">
              <span className="font-medium">
                {transaction.description}
              </span>
              <span className={cn(
                "font-medium",
                transaction.amount < 0 ? "text-black" : "text-green-600"
              )}>
                {transaction.amount < 0 ? "- " : "+ "}
                ₱{Math.abs(transaction.amount).toLocaleString()}
              </span>
            </div>
            <div className="text-sm text-gray-500">
              {transaction.date}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

