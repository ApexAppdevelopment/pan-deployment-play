"use client"

import { useState } from "react"
import { Mic, AudioWaveformIcon as Waveform } from 'lucide-react'
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

export function VoiceAssistant() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        variant="ghost"
        size="icon"
        className="fixed bottom-20 right-4 h-12 w-12 rounded-full bg-purple-600 hover:bg-purple-700"
      >
        <Waveform className="h-6 w-6 text-white" />
      </Button>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <div className="flex flex-col items-center gap-4 p-4">
            <div className="text-2xl font-bold">Panyero Assistant</div>
            <div className="h-32 w-32 rounded-full bg-purple-100 flex items-center justify-center">
              <Mic className="h-16 w-16 text-purple-600" />
            </div>
            <div className="text-center text-sm text-muted-foreground">
              How can I help you today?
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

