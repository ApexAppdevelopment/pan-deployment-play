import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { LucideIcon } from "lucide-react"

interface PlaceholderServicePageProps {
  title: string
  icon: LucideIcon
}

export function PlaceholderServicePage({ title, icon: Icon }: PlaceholderServicePageProps) {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6 flex items-center">
          <Icon className="mr-2 h-8 w-8" />
          {title}
        </h1>
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <p className="text-gray-600 mb-4">
            This feature is coming soon! We're working hard to bring you the best {title.toLowerCase()} experience.
          </p>
          <Button>Notify Me When Available</Button>
        </div>
      </div>
      <BottomNav />
    </main>
  )
}

