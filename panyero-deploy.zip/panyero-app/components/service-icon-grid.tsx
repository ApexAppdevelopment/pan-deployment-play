import { Button } from "@/components/ui/button"
import Link from "next/link"
import { LucideIcon } from "lucide-react"

interface ServiceIcon {
  icon: LucideIcon
  label: string
  href: string
}

interface ServiceCategory {
  title: string
  icons: ServiceIcon[]
}

interface ServiceIconGridProps {
  categories: ServiceCategory[]
}

export function ServiceIconGrid({ categories }: ServiceIconGridProps) {
  return (
    <div className="space-y-6">
      {categories.map((category, index) => (
        <div key={index}>
          <h2 className="text-lg font-semibold mb-3">{category.title}</h2>
          <div className="grid grid-cols-4 gap-4">
            {category.icons.map((icon, iconIndex) => (
              <Button
                key={iconIndex}
                variant="ghost"
                className="flex flex-col items-center justify-center h-24"
                asChild
              >
                <Link href={icon.href}>
                  <icon.icon className="h-8 w-8 mb-2" />
                  <span className="text-xs text-center">{icon.label}</span>
                </Link>
              </Button>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

