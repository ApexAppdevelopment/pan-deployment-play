"use client"

import { useState } from "react"
import { Bot, Copy, Check } from 'lucide-react'
import { Button } from "@/components/ui/button"

export function FloatingAssistant() {
  const [isOpen, setIsOpen] = useState(false)
  const [isCopied, setIsCopied] = useState(false)

  const handleCopy = () => {
    navigator.clipboard.writeText("https://aitekph.com/niyero")
    setIsCopied(true)
    setTimeout(() => setIsCopied(false), 2000)
  }

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        variant="ghost"
        size="icon"
        className="fixed bottom-24 right-4 h-12 w-12 rounded-full bg-purple-600 hover:bg-purple-700 shadow-lg z-50"
      >
        <Bot className="h-6 w-6 text-white" />
      </Button>
      {isOpen && (
        <div className="fixed inset-0 bg-white z-50 flex flex-col">
          <iframe
            src="https://aitekph.com/niyero"
            className="w-full h-full"
            allow="microphone; autoplay"
          />
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 right-4 bg-white rounded-full shadow-md"
            onClick={() => setIsOpen(false)}
          >
            <Bot className="h-6 w-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="absolute bottom-4 right-4 bg-white rounded-full shadow-md"
            onClick={handleCopy}
          >
            {isCopied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
          </Button>
        </div>
      )}
    </>
  )
}

