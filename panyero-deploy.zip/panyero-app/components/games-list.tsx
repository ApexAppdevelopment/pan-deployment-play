"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"
import { placeBet } from "@/app/actions/casino"
import { useAuth } from "@/contexts/auth-context"

interface Game {
  id: string
  sport_key: string
  sport_title: string
  commence_time: string
  home_team: string
  away_team: string
  bookmakers: {
    key: string
    title: string
    markets: {
      key: string
      outcomes: {
        name: string
        price: number
      }[]
    }[]
  }[]
}

export function GamesList() {
  const { user } = useAuth()
  const [games, setGames] = useState<Game[]>([])
  const [loading, setLoading] = useState(true)
  const [betAmounts, setBetAmounts] = useState<{ [key: string]: string }>({})

  useEffect(() => {
    fetchGames()
  }, [])

  const fetchGames = async () => {
    try {
      const response = await fetch('/api/odds')
      if (!response.ok) {
        throw new Error('Failed to fetch games')
      }
      const data = await response.json()
      setGames(data)
    } catch (error) {
      console.error('Error fetching games:', error)
      toast.error('Failed to load games')
    } finally {
      setLoading(false)
    }
  }

  const handleBetAmountChange = (gameId: string, amount: string) => {
    setBetAmounts(prev => ({ ...prev, [gameId]: amount }))
  }

  const handlePlaceBet = async (game: Game, outcome: string, price: number) => {
    if (!user) {
      toast.error("Please log in to place a bet")
      return
    }

    const betAmount = parseFloat(betAmounts[game.id] || "0")
    if (isNaN(betAmount) || betAmount <= 0) {
      toast.error("Please enter a valid bet amount")
      return
    }

    try {
      const result = await placeBet(game.id, outcome, betAmount, price)
      if (result.success) {
        toast.success(`Bet of $${betAmount} placed on ${outcome} for ${game.home_team} vs ${game.away_team}`)
        setBetAmounts(prev => ({ ...prev, [game.id]: "" }))
      } else {
        toast.error(result.error || "Failed to place bet")
      }
    } catch (error) {
      console.error('Error placing bet:', error)
      toast.error("Failed to place bet")
    }
  }

  if (loading) {
    return <div>Loading games...</div>
  }

  return (
    <div className="space-y-4">
      {games.map((game) => (
        <Card key={game.id}>
          <CardHeader>
            <CardTitle>{game.home_team} vs {game.away_team}</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Sport: {game.sport_title}</p>
            <p>Start Time: {new Date(game.commence_time).toLocaleString()}</p>
            {game.bookmakers[0]?.markets[0]?.outcomes.map((outcome) => (
              <div key={outcome.name} className="flex items-center justify-between mt-2">
                <span>{outcome.name}: {outcome.price}</span>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    placeholder="Bet amount"
                    value={betAmounts[game.id] || ""}
                    onChange={(e) => handleBetAmountChange(game.id, e.target.value)}
                    className="w-24"
                  />
                  <Button 
                    onClick={() => handlePlaceBet(game, outcome.name, outcome.price)}
                    disabled={!user}
                  >
                    {user ? "Bet" : "Login to Bet"}
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

