const API_URL = 'https://api.opensea.io/api/v1'

export const fetchPorts = async () => {
  try {
    const response = await fetch(`${API_URL}/ports`)
    const data = await response.json()
    return data.ports.map((port: any) => ({
      id: port.id,
      name: port.name,
      coordinates: [port.longitude, port.latitude]
    }))
  } catch (error) {
    console.error('Error fetching ports:', error)
    return []
  }
}

