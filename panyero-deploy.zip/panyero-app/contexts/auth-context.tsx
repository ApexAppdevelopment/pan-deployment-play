import React, { createContext, useContext, useState, useEffect } from 'react'
import { auth, db } from '@/lib/firebase'
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut as firebaseSignOut, 
  sendPasswordResetEmail,
  updateProfile,
  onAuthStateChanged, 
  User 
} from 'firebase/auth'
import { setDoc, doc, getDoc, updateDoc } from 'firebase/firestore'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'

interface AuthContextType {
  user: User | null
  signUp: (email: string, password: string, fullName: string) => Promise<void>
  signIn: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  resetPassword: (email: string) => Promise<void>
  updateUserProfile: (data: { displayName?: string, photoURL?: string }) => Promise<void>
  getProfile: () => Promise<any>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const router = useRouter()

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user)
    })
    return () => unsubscribe()
  }, [])

  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)
      const user = userCredential.user

      await updateProfile(user, { displayName: fullName })

      await setDoc(doc(db, 'users', user.uid), {
        email,
        fullName,
        createdAt: new Date(),
      })

      toast.success('Account created successfully.')
      router.push('/')
    } catch (error) {
      console.error("Error during sign up:", error)
      toast.error('Failed to create account. Please try again.')
      throw error
    }
  }

  const signIn = async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password)
      toast.success('Signed in successfully.')
      router.push('/')
    } catch (error) {
      console.error("Error during sign in:", error)
      toast.error('Failed to sign in. Please check your credentials.')
      throw error
    }
  }

  const signOut = async () => {
    try {
      await firebaseSignOut(auth)
      toast.success('Signed out successfully.')
      router.push('/auth/sign-in')
    } catch (error) {
      console.error("Error during sign out:", error)
      toast.error('Failed to sign out. Please try again.')
      throw error
    }
  }

  const resetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email)
      toast.success('Password reset email sent. Check your inbox.')
    } catch (error) {
      console.error("Error sending password reset email:", error)
      toast.error('Failed to send password reset email. Please try again.')
      throw error
    }
  }

  const updateUserProfile = async (data: { displayName?: string, photoURL?: string }) => {
    if (!user) throw new Error('No user logged in')
    try {
      await updateProfile(user, data)
      await updateDoc(doc(db, 'users', user.uid), data)
      toast.success('Profile updated successfully.')
    } catch (error) {
      console.error("Error updating profile:", error)
      toast.error('Failed to update profile. Please try again.')
      throw error
    }
  }

  const getProfile = async () => {
    if (!user) return null
    const docRef = doc(db, 'users', user.uid)
    const docSnap = await getDoc(docRef)
    return docSnap.exists() ? docSnap.data() : null
  }

  const value = {
    user,
    signUp,
    signIn,
    signOut,
    resetPassword,
    updateUserProfile,
    getProfile,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

