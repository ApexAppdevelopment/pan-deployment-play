import { createClient } from '@supabase/supabase-js'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'
import type { Database } from '@/types/supabase'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Missing Supabase environment variables. Using fallback values for development.')
}

// Use fallback values for development if environment variables are not set
const fallbackUrl = 'https://your-project-id.supabase.co'
const fallbackAnonKey = 'your-anon-key'

export const supabase = createClientComponentClient<Database>({
  supabaseUrl: supabaseUrl || fallbackUrl,
  supabaseKey: supabaseAnonKey || fallbackAnonKey,
})

// For server-side operations
export const createServerSupabaseClient = () => createClient(
  supabaseUrl || fallbackUrl,
  supabaseAnonKey || fallbackAnonKey
)

