const RAPIDAPI_KEY = '59ade3810amsh5866fb91182ed4fp11b245jsn9a0da3a16e46'
const RAPIDAPI_HOST = 'paddy-power-gambling-games.p.rapidapi.com'

export interface CasinoGame {
  id: string
  name: string
  type: string
  thumbnail: string
  description: string
  provider: string
  popularity: number
  isNew?: boolean
  isHot?: boolean
}

export async function fetchCasinoGames(): Promise<CasinoGame[]> {
  const options = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': RAPIDAPI_KEY,
      'X-RapidAPI-Host': RAPIDAPI_HOST,
    },
    next: { revalidate: 3600 } // Cache for 1 hour
  }

  try {
    const response = await fetch('https://paddy-power-gambling-games.p.rapidapi.com/games', options)
    
    if (!response.ok) {
      throw new Error('Failed to fetch casino games')
    }

    const data = await response.json()
    
    // Transform the API response to match our interface
    return data.games.map((game: any) => ({
      id: game.id || String(Math.random()),
      name: game.name,
      type: game.type || 'slot',
      thumbnail: game.thumbnail || '/placeholder.svg?height=200&width=300',
      description: game.description || 'Experience this exciting casino game',
      provider: game.provider || 'Casino Provider',
      popularity: game.popularity || Math.floor(Math.random() * 1000),
      isNew: game.isNew || false,
      isHot: game.popularity > 800 || false
    }))
  } catch (error) {
    console.error('Error fetching casino games:', error)
    return []
  }
}

