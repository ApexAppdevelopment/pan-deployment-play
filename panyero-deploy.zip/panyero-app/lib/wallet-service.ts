import { db } from './firebase'
import { collection, query, where, getDocs, addDoc, updateDoc, doc, orderBy, limit, startAfter } from 'firebase/firestore'

export interface Wallet {
  id: string
  userId: string
  balance: number
  currency: string
}

export interface Transaction {
  id: string
  userId: string
  type: string
  amount: number
  currency: string
  description: string
  createdAt: Date
}

export async function getWallet(userId: string): Promise<Wallet | null> {
  const walletsRef = collection(db, 'wallets')
  const q = query(walletsRef, where("userId", "==", userId))
  const querySnapshot = await getDocs(q)

  if (querySnapshot.empty) {
    return null
  }

  const walletDoc = querySnapshot.docs[0]
  return { id: walletDoc.id, ...walletDoc.data() } as Wallet
}

export async function createWallet(userId: string, currency: string = 'PHP'): Promise<Wallet> {
  const walletsRef = collection(db, 'wallets')
  const newWallet = {
    userId,
    balance: 0,
    currency,
  }
  const docRef = await addDoc(walletsRef, newWallet)
  return { id: docRef.id, ...newWallet }
}

export async function updateWalletBalance(
  userId: string,
  amount: number,
  type: 'credit' | 'debit'
): Promise<Wallet> {
  const walletsRef = collection(db, 'wallets')
  const q = query(walletsRef, where("userId", "==", userId))
  const querySnapshot = await getDocs(q)

  if (querySnapshot.empty) {
    throw new Error('Wallet not found')
  }

  const walletDoc = querySnapshot.docs[0]
  const currentBalance = walletDoc.data().balance

  const newBalance = type === 'credit' ? currentBalance + amount : currentBalance - amount

  if (type === 'debit' && newBalance < 0) {
    throw new Error('Insufficient funds')
  }

  await updateDoc(walletDoc.ref, { balance: newBalance })

  return { id: walletDoc.id, userId, balance: newBalance, currency: walletDoc.data().currency }
}

export async function createTransaction(
  userId: string,
  type: string,
  amount: number,
  currency: string,
  description: string
): Promise<Transaction> {
  const transactionsRef = collection(db, 'transactions')
  const newTransaction = {
    userId,
    type,
    amount,
    currency,
    description,
    createdAt: new Date(),
  }
  const docRef = await addDoc(transactionsRef, newTransaction)
  return { id: docRef.id, ...newTransaction }
}

export async function getTransactions(
  userId: string,
  limitCount: number = 10,
  offsetId?: string
): Promise<Transaction[]> {
  const transactionsRef = collection(db, 'transactions')
  let q = query(
    transactionsRef, 
    where("userId", "==", userId),
    orderBy("createdAt", "desc"),
    limit(limitCount)
  )

  if (offsetId) {
    const startAfterDoc = await getDocs(query(transactionsRef, where("id", "==", offsetId)))
    if (!startAfterDoc.empty) {
      q = query(q, startAfter(startAfterDoc.docs[0]))
    }
  }

  const querySnapshot = await getDocs(q)
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction))
}

