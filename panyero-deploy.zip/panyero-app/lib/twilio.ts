import twilio from 'twilio'

const accountSid = 'AC630cb5025d5c12d8c6fda9038dd09645'
const authToken = '538df692bc75c340f1080730030c12c7'
const client = twilio(accountSid, authToken)

export async function sendOTP(phoneNumber: string): Promise<void> {
  try {
    const verification = await client.verify.v2.services('VAXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX')
      .verifications
      .create({ to: phoneNumber, channel: 'sms' })
    
    console.log(`OTP sent to ${phoneNumber}. Status: ${verification.status}`)
  } catch (error) {
    console.error('Error sending OTP:', error)
    throw error
  }
}

export async function verifyOTP(phoneNumber: string, code: string): Promise<boolean> {
  try {
    const verificationCheck = await client.verify.v2.services('VAXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX')
      .verificationChecks
      .create({ to: phoneNumber, code })
    
    return verificationCheck.status === 'approved'
  } catch (error) {
    console.error('Error verifying OTP:', error)
    throw error
  }
}

